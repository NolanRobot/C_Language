#ifndef PROJ_H___
#define PROJ_H___

extern int i;

extern void call_func(void);

#endif
