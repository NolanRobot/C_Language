#include<stdio.h>
#include<stdlib.h>

#include "proj.h"

static void func(void)
{
	printf("[%s]: i = %d\n", __FUNCTION__, i);

	exit(0);
}

void call_func(void)
{
	func();

	exit(0);
}
